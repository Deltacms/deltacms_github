<?php
// Lexique du module du coeur Install en espagnol
$text['core_install_view']['update'][0] = 'Actualización de Deltacms ';
$text['core_install_view']['update'][1] = ' to Deltacms ';
$text['core_install_view']['update'][2] = 'Para garantizar el correcto funcionamiento de Deltacms, no cierre esta página antes de que finalice la operación.';
$text['core_install_view']['update'][3] = '1/4: Preparando...';
$text['core_install_view']['update'][4] = '2/4: Descargando...';
$text['core_install_view']['update'][5] = '3/4: Instalando...';
$text['core_install_view']['update'][6] = '4/4: Configuración...';
$text['core_install_view']['update'][7] = 'Ocurrió un error durante el paso';
$text['core_install_view']['update'][8] = 'Actualización completada con éxito';
$text['core_install_view']['update'][9] = 'Finalizar';
$text['core_install']['update'][0] = 'Actualizar';
$text['core_install']['index'][0] = 'Instalación de su sitio';
$text['core_install']['index'][1] = 'Hola';
$text['core_install']['index'][2] = 'Aquí están los detalles de su instalación';
$text['core_install']['index'][3] = 'URL del sitio';
$text['core_install']['index'][4] = 'ID de cuenta';
$text['core_install']['index'][5] = 'Instalación completa';
// Nom de la page d'accueil dans cette langue d'administration
$text['core_install']['index'][6] = 'inicio.html';
// Texte par défaut à gauche du footer
$text['core_install']['index'][7] = 'Pie de página personalizado';
// Texte pour la bannière customisable
$text['core_install']['index'][8] = 'Banner vacío';
// Texte pour le lien vers la page d'accueil
$text['core_install']['index'][9] = 'inicio';
?>