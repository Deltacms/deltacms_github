<?php
// Lexique du module du coeur Sitemap en français
$text['core_sitemap']['index'][0] = 'Plan du site';

?>