<?php
// Lexique du module du coeur Maintenance en espagnol
$text['core_maintenance']['index'][0] = 'Mantenimiento en curso...';
$text['core_maintenance']['index'][1] = "Nuestro sitio está actualmente en mantenimiento. Lamentamos las molestias y estamos haciendo todo lo posible para regresar pronto.";
?>