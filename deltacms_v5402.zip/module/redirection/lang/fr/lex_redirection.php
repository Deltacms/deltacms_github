<?php
// Lexique du module redirection
$text['redirection_view']['config'][0] = 'Retour';
$text['redirection_view']['config'][1] = 'Enregistrer';
$text['redirection_view']['config'][2] = 'Lien de redirection';
$text['redirection_view']['config'][3] = 'Le lien de redirection peut contenir une URL standard, ou pointer vers l\'ancre d\'une page du site <em>(/page#ancre)</em> ; <em>(/?page#ancre)</em>';
$text['redirection_view']['config'][4] = 'Redirection';
$text['redirection_view']['config'][5] = 'Statistiques';
$text['redirection_view']['config'][6] = 'Nombre de redirections';
$text['redirection_view']['config'][7] = 'Version n°';
$text['redirection_view']['config'][8] = 'Aide';
$text['redirection_view']['config'][9] = 'module/redirection/view/config/config.help.html';
$text['redirection_view']['index'][0] = 'OUI : éditer la page | NON : tester la redirection.';
$text['redirection']['config'][0] = 'Modifications enregistrées';
$text['redirection']['config'][1] = 'Configuration du module';
?>