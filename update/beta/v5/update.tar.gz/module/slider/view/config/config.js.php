/**
 * This file is part of DeltaCMS.
 */

/**
 * Sélection d'un nouveau dossier
 */
$("#galleryEditDirectory").on("change", function() {
	$("#galleryEditLabelView").removeClass('displayNone');
});

