<?php
// Lexique du module du coeur Maintenance en français
$text['core_maintenance']['index'][0] = 'Maintenance en cours...';
$text['core_maintenance']['index'][1] = "Notre site est actuellement en maintenance. Nous sommes désolés pour la gêne occasionnée et faisons notre possible pour être rapidement de retour.";
?>