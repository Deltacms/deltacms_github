<?php
// Lexique du module du coeur Maintenance en anglais
$text['core_maintenance']['index'][0] = 'Maintenance in progress...';
$text['core_maintenance']['index'][1] = "Our site is currently undergoing maintenance. We apologise for the inconvenience and are doing our best to be back soon.";
?>