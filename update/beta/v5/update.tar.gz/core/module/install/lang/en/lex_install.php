<?php
// Lexique du module du coeur Install en anglais
$text['core_install_view']['update'][0] = 'Updating Deltacms ';
$text['core_install_view']['update'][1] = ' to Deltacms ';
$text['core_install_view']['update'][2] = 'To ensure the proper functioning of Deltacms, please do not close this page until the operation is complete.';
$text['core_install_view']['update'][3] = '1/4: Preparation...';
$text['core_install_view']['update'][4] = '2/4 : Download...';
$text['core_install_view']['update'][5] = '3/4 : Installation...';
$text['core_install_view']['update'][6] = '4/4 : Configuration...';
$text['core_install_view']['update'][7] = 'An error occurred in the step';
$text['core_install_view']['update'][8] = 'Update successfully completed.';
$text['core_install_view']['update'][9] = 'Finish';
$text['core_install']['update'][0] = 'Update';
$text['core_install']['index'][0] = 'Setting up your website';
$text['core_install']['index'][1] = 'Hello';
$text['core_install']['index'][2] = 'Here are the details of your installation';
$text['core_install']['index'][3] = 'Site URL';
$text['core_install']['index'][4] = 'Account ID';
$text['core_install']['index'][5] = 'Installation completed';
// Nom de la page d'accueil dans cette langue d'administration
$text['core_install']['index'][6] = 'home.html';
// Texte par d�faut � gauche du footer
$text['core_install']['index'][7] = 'Custom footer';
// Texte pour la banni�re customisable
$text['core_install']['index'][8] = 'Banner empty';
// Texte pour le lien vers la page d'accueil
$text['core_install']['index'][9] = 'home';
?>